import React from 'react';
import ValidatedLoginForm from './ValidatedLoginForm';
function App(){
  return(
    <div> 
      <ValidatedLoginForm/>
    </div>
  );
}

export default App